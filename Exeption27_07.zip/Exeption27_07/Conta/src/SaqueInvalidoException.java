
public class SaqueInvalidoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SaqueInvalidoException(String message) {
	        super(message);
}
	
}

