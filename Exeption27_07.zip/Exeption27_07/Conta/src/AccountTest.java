import java.util.Scanner;

public class AccountTest {

	public static void main(String[] args){
		try {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your account number: ");
		Integer number = sc.nextInt();
		System.out.println("Enter your name: ");
		String holder = sc.nextLine();
		sc.nextLine();
		System.out.println("Enter your blance current: ");
		double balance = sc.nextDouble();
		System.out.println("Enter your With Dranw Limit: ");
		double withdrawLimit = sc.nextDouble();
		
		Account ac1 = new Account(number,holder,balance,withdrawLimit);
		
		System.out.println("Enter amount of the with draw limit: ");
		double amount = sc.nextDouble();
		ac1.withdraw(amount);
		
		} catch (SaqueInvalidoException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

}
