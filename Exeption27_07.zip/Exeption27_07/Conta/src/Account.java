
public class Account {
	protected Integer number;
	protected String holder;
	protected double balance;
	protected double withdrawLimit;
	
	
	public Account(Integer number, String holder, double balance, double withdrawLimit) {
		super();
		this.number = number;
		this.holder = holder;
		this.balance = balance;
		this.withdrawLimit = withdrawLimit;
	}

	public void deposit(double amount) {
		if( amount > 0) {
			balance += amount;
			System.out.println(balance);
		}
	}
	
	

	public void withdraw(double amount) throws SaqueInvalidoException {
        if (amount <= 0) {
            throw new SaqueInvalidoException("The amount must be greater than zero");
        } else if (amount > balance && amount > withdrawLimit) {
            throw new SaqueInvalidoException("insufficient balance");
        } else {
            balance -= amount;
            System.out.println("With Draw finish! New balance: R$ " + balance);
        }
    }

	}

