package VetoresEx1;

public class Vetores {
	public static void main(String[] args) {
		int[][] matrizes = new int[10][20];
		int v = 1;
System.out.println(matrizes.length);
		for (int i = 0; i < matrizes.length; i++) {
			for (int j = 0; j < matrizes[i].length; j++) {
				matrizes[i][j] = v++;
			}
		}
		for (int i = 0; i < matrizes.length; i++) {
			for (int j = 0; j < matrizes[i].length; j++) {
				System.out.print(matrizes[i][j] + " ");
			}
			System.out.println();
		}
	}
}
