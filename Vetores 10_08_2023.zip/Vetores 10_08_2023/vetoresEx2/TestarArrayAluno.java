package vetoresEx2;

public class TestarArrayAluno {

	public static void main(String[] args) {
	Aluno[] turma = new Aluno[5];	
	
	turma[0]= new Aluno("Pedro", 5, 6);
	turma[1]= new Aluno("Milena", 10, 6);
	turma[2]= new Aluno("Pedro Alex Madagascar", 7, 3);
	turma[3]= new Aluno("Gb", 7, 6);
	turma[4]= new Aluno("Guto", 7, 6);
	
	System.out.println("Lista de Alunos:");
	   for (Aluno aluno : turma) {
        double media = aluno.caucularMedia();
        System.out.println("Nome: " + aluno.getNome() + ", M�dia: " + media);
    }
	
	}

}
